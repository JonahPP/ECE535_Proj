import cv2
import datetime
import matplotlib.pyplot as plt
import numpy as np 
import os
import pandas as pd




GT_filepath = 'C:\\Users\\danka\\Downloads\\example\\gt_poses\\09.txt'
Kitti_filepath = 'C:\\Users\\danka\\Downloads\\example\\KITTI\\09.txt'



# Read the file using pandas read_csv with custom parameters
GT_poses = pd.read_csv(GT_filepath, delimiter=' ', header=None)

Kitti_poses = pd.read_csv(Kitti_filepath, delimiter=' ', header=None)

# Display the number of rows and columns in the dataframe
print("Shape of the ground truth:", GT_poses.shape)
print("Shape of the result data:", Kitti_poses.shape)


# the array tells us the camera location in reference of the global frame
# rotation matrix 3x3 ([R|t] which shows how much it rotated)
# translation matrix, the last column shows the difference in distance from one frame to another

# this shows the first position #.round(2)
x = np.array(GT_poses.iloc[0]).reshape((3,4))
print(x)


# # need to make it a 4-d vector with the 1 at the end
# origin = np.array([0,0,0,1])
# first_pose.dot(origin)

# z direction points to camera, x points right and left, y points up and down


gt = np.zeros((len(GT_poses), 3, 4))
for i in range(len(GT_poses)):
    gt[i] = np.array(GT_poses.iloc[i]).reshape((3, 4))
    
    
fig = plt.figure(figsize=(7,6))
ax= fig.add_subplot(111, projection='3d')
ax.plot(gt[:, :, 3][:, 0], gt[:, :, 3][:, 1], gt[:, :, 3][:, 2])

ax.plot(Kitti_poses[0], Kitti_poses[1], Kitti_poses[2])

ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')

plt.show()



def calculate_error(ground_truth, estimated, error_type='mse'):
    '''
    Takes arrays of ground truth and estimated poses of shape Nx3x4, and computes error using
    Euclidean distance between true and estimated 3D coordinate at each position.
    
    Arguments:
    ground_truth -- Nx3x4 array of ground truth poses
    estimated -- Nx3x4 array of estimated poses
    
    Optional Arguments:
    error_type -- (str) can be 'mae', 'mse', 'rmse', or 'all' to return dictionary of all 3
    
    Returns:
    error -- either a float or dictionary of error types and float values
    
    '''
    # Find the number of frames in the estimated trajectory to compare with
    nframes_est = estimated.shape[0]
    
    def get_mse(ground_truth, estimated):
        se = np.sqrt((ground_truth[nframes_est, 0, 3] - estimated[:, 0, 3])**2 
                    + (ground_truth[nframes_est, 1, 3] - estimated[:, 1, 3])**2 
                    + (ground_truth[nframes_est, 2, 3] - estimated[:, 2, 3])**2)**2
        mse = se.mean()
        return mse
    
    def get_mae(ground_truth, estimated):
        ae = np.sqrt((ground_truth[nframes_est, 0, 3] - estimated[:, 0, 3])**2 
                    + (ground_truth[nframes_est, 1, 3] - estimated[:, 1, 3])**2 
                    + (ground_truth[nframes_est, 2, 3] - estimated[:, 2, 3])**2)
        mae = ae.mean()
        return mae
    
    if error_type == 'mae':
        return get_mae(ground_truth, estimated)
    elif error_type == 'mse':
        return get_mse(ground_truth, estimated)
    elif error_type == 'rmse':
        return np.sqrt(get_mse(ground_truth, estimated))
    elif error_type == 'all':
        mae = get_mae(ground_truth, estimated)
        mse = get_mse(ground_truth, estimated)
        rmse = np.sqrt(mse)
        return {'mae': mae,
                'rmse': rmse,
                'mse': mse}
        

# calculate_error(handler.gt, trajectory_lidar_sgbm, 'all')