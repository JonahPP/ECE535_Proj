FILE = "V_101"

PYTHON = "& C:/Users/joshu/AppData/Local/Programs/Python/Python311/python.exe"

GT_File = f"C:\\Users\\joshu\\Documents\\Development\\TartanVO\\535project\\535project\\Euroc_gt_txt\\{FILE}.txt"
EST_File = f"C:\\Users\\joshu\\Documents\\Development\\TartanVO\\535project\\535project\\Euroc\\{FILE}.txt"

SAVE = f"C:\\Users\\joshu\\Documents\\Development\\TartanVO\\example\\ATE_data_offset\\{FILE}.txt"
PLOT = f"C:\\Users\\joshu\\Documents\\Development\\TartanVO\\example\\ATE_PLOTS\\{FILE}.pdf"

SCRIPT =  "C:\\Users\\joshu\\Documents\\Development\\TartanVO\\535project\\535project\\evaluate_ate_scale.py"

if __name__=="__main__":
    statement = f"{SCRIPT} {GT_File} {EST_File} --save {SAVE} --plot {PLOT} --verbose"
    print(statement)