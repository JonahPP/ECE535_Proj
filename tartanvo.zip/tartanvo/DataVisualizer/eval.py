import numpy as np
import matplotlib.pyplot as plt

# Load x and y data from text files
gt_data = np.loadtxt('DataVisualizer/TrimmedData/pose_gt.txt')
est_data = np.loadtxt('DataVisualizer/TrimmedData/pose_est.txt')

# # Separate the data into x and y arrays
est_x_array = est_data[:, 0]  # First column (x positions)
est_y_array = est_data[:, 1]  # Second column (y positions)

gt_x_array = gt_data[:, 0]  # First column (x positions)
gt_y_array = gt_data[:, 1]  # Second column (y positions)

# # Create a scatter plot
plt.scatter(gt_x_array, gt_y_array)
plt.scatter(est_x_array, est_y_array)

# # Add labels and title
plt.xlabel('X Position')
plt.ylabel('Y Position')
plt.title('Scatter Plot of X and Y Position Data')

# # Show the plot
plt.show()

