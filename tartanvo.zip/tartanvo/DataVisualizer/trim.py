import os

def copy_first_three_columns(input_folder, output_folder):
    # Ensure the output folder exists
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # List all files in the input folder
    files = [f for f in os.listdir(input_folder) if os.path.isfile(os.path.join(input_folder, f))]

    for file_name in files:
        input_file_path = os.path.join(input_folder, file_name)
        output_file_path = os.path.join(output_folder, file_name)

        with open(input_file_path, 'r') as input_file, open(output_file_path, 'w') as output_file:
            for line in input_file:
                # Split the line into columns
                columns = line.strip().split()

                # Take the first three columns
                first_three_columns = columns[:2]

                # Write the first three columns to the output file
                output_file.write(' '.join(first_three_columns) + '\n')

if __name__ == "__main__":
    # Replace 'input_folder' and 'output_folder' with your actual folder paths
    input_folder ="C:\\Users\\joshu\\Documents\\Development\\TartanVO\\tartanvo\\DataVisualizer\\OriginalData"
    output_folder ="C:\\Users\\joshu\\Documents\\Development\\TartanVO\\tartanvo\\DataVisualizer\\TrimmedData"
    copy_first_three_columns(input_folder, output_folder)

    print("Files copied successfully.")